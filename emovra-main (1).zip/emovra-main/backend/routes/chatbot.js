import express from "express";
import { GoogleGenerativeAI } from "@google/generative-ai";
import optionalAuth from "../middleware/optionalAuth.js";
import { localRiskFallback } from "../utils/localRiskFallback.js";
import { saveAnalysis } from "../utils/saveAnalysis.js";
import { awardXP } from "../utils/gamification.js";

const router = express.Router();
const GEMINI_MODEL = "gemini-1.5-flash";

const SYSTEM_PROMPT = `
You are Emovra AI, a warm, curious companion for mental wellness check-ins.
Your job in this conversation: help the person open up a bit more so their
mood/journal entries are understood accurately - NOT to diagnose or lecture.

Rules:
- Keep replies short (2-4 sentences).
- Ask ONE genuine follow-up question per reply when it's natural to (not
  every single time - don't interrogate).
- Be specific to what they actually said, not generic.
- Never say "as an AI" or break character.
- Never give medical diagnoses. If they mention self-harm, abuse, or being
  unsafe, respond with warmth and gently encourage reaching out to
  Tele-MANAS (14416) - but keep it natural, not a canned disclaimer.
`;

// This route ALSO silently runs the same keyword-based risk check every
// other entry point in this app uses (see utils/localRiskFallback.js), and
// saves RED/ORANGE the same way analyze.js does. Without this, a chatbot
// conversation would be a blind spot where someone could disclose something
// serious and it would never reach the crisis-detection pipeline at all -
// that's not acceptable for this app, chatbot or not.
router.post("/", optionalAuth, async (req, res) => {
  try {
    const { messages } = req.body; // [{ role: 'user'|'assistant', text }]
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ success: false, message: "messages array required" });
    }

    const lastUserMsg = [...messages].reverse().find((m) => m.role === "user");
    const userId = req.user?.id || req.body.userId || "anonymous";

    // 1. Safety net - runs on every message, regardless of what the
    // conversational reply below says.
    if (lastUserMsg?.text) {
      const risk = localRiskFallback(lastUserMsg.text);
      if (risk.risk === "RED" || risk.risk === "ORANGE") {
        await saveAnalysis({
          userId,
          text: lastUserMsg.text,
          risk: risk.risk,
          score: risk.score,
          category: risk.category,
          abuseType: risk.abuseType,
          abuseSource: risk.abuseSource,
          triggers: risk.triggers,
        });
      }
    }

    // 2. Conversational reply
    let reply = "I'm here. Tell me a bit more about what's going on?";
    if (process.env.GEMINI_API_KEY) {
      try {
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: GEMINI_MODEL });
        const transcript = messages
          .slice(-10) // keep prompt small
          .map((m) => `${m.role === "user" ? "Person" : "Emovra"}: ${m.text}`)
          .join("\n");
        const result = await model.generateContent(`${SYSTEM_PROMPT}\n\nConversation so far:\n${transcript}\n\nEmovra:`);
        reply = result.response.text().trim() || reply;
      } catch (e) {
        console.error("Chatbot Gemini error:", e.message?.slice(0, 200));
        reply = "I'm having a little trouble thinking right now, but I'm still here - go on, I'm listening.";
      }
    }

    // 3. XP for a real conversation (awarded once, right as it crosses the
    // threshold - not every message).
    const userTurns = messages.filter((m) => m.role === "user").length;
    let gam = null;
    if (req.user?.id && userTurns === 3) {
      gam = await awardXP(req.user.id, 10, { chatbotUsed: true });
    }

    res.json({ success: true, reply, gamification: gam });
  } catch (err) {
    console.error("Chatbot error:", err);
    res.status(500).json({ success: false, message: "Chatbot failed", reply: "Sorry, I lost my train of thought - try again?" });
  }
});

export default router;
